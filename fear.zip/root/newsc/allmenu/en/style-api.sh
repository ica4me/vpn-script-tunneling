#!/bin/bash

ResponseJsonALLVmess() {
cat > "/etc/xray/${user}-vmess-panel-config.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Create VMESS Success"
  },
  "data": {
    "hostname": "${domain}",
    "ISP": "${isp}",
    "CITY": "${city}",
    "username": "${user}",
    "expired": "${exp}",
    "uuid": "${uuid}",
    "time": "${timedays}",
    "port": {
      "tls": "443, 8443",
      "none": "80, 8080",
      "any": "2052, 2053, 8880"
    },
    "path": {
      "stn": "/vmess",
      "multi": "/yourbug",
      "grpc": "vmess",
      "up": "/upvmess"
    },
    "link": {
      "tls": "${vmesslink1}",
      "none": "${vmesslink2}",
      "grpc": "${vmesslink3}",
      "uptls": "${vmesslink4}",
      "upntls": "${vmesslink5}"
    }
  }
}
END
cat "/etc/xray/${user}-vmess-panel-config.json" | jq .
}

ResponseJsonALLVless() {
cat > "/etc/xray/${user}-vless-panel-config.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Create VLESS Success"
  },
  "data": {
    "hostname": "${domain}",
    "ISP": "${isp}",
    "CITY": "${city}",
    "username": "${user}",
    "expired": "${exp}",
    "uuid": "${uuid}",
    "time": "${timedays}",
    "port": {
      "tls": "443, 8443",
      "none": "80, 8080",
      "any": "2052, 2053, 8880"
    },
    "path": {
      "stn": "/vless",
      "multi": "/yourbug/vless",
      "grpc": "vless",
      "up": "/upvless"
    },
    "link": {
      "tls": "${vlesslink1}",
      "none": "${vlesslink2}",
      "grpc": "${vlesslink3}",
      "uptls": "${vlesslink4}",
      "upntls": "${vlesslink5}"
    }
  }
}
END
cat "/etc/xray/${user}-vless-panel-config.json" | jq .
}

ResponseJsonALLTrojan() {
cat > "/etc/xray/${user}-trojan-panel-config.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Create TROJAN Success"
  },
  "data": {
    "hostname": "${domain}",
    "ISP": "${isp}",
    "CITY": "${city}",
    "username": "${user}",
    "expired": "${exp}",
    "uuid": "${uuid}",
    "time": "${timedays}",
    "port": {
      "tls": "443, 8443",
      "any": "2052, 2053, 8880"
    },
    "path": {
      "stn": "/trojan",
      "multi": "/yourbug/trojan",
      "grpc": "trojan",
      "up": "/uptrojan"
    },
    "link": {
      "tls": "${trojanlink}",
      "grpc": "${trojanlink1}",
      "uptls": "${trojanlink2}"
    }
  }
}
END
cat "/etc/xray/${user}-trojan-panel-config.json" | jq .
}

ResponseJsonALLSSH() {
  cat > "/etc/xray/${Login}-ssh-panel.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Create SSH Success"
  },
  "data": {
    "hostname": "${domain}",
    "ISP": "${isp}",
    "CITY": "${city}",
    "username": "${Login}",
    "servername": "${ns}",
    "pubkey": "${pub}",
    "password": "${Pass}",
    "exp": "${exp}",
    "time": "${timedays}",
    "port": {
      "tls": "443, 8443",
      "none": "80, 8080",
      "any": "2082, 2083, 8880",
      "ovpntcp": 1194,
      "ovpnudp": 25000,
      "slowdns": "53, 5300",
      "sshohp": 9080,
      "ovpnohp": 9088,
      "squid": 3128,
      "udpcustom": "1-65535",
      "udpgw": "7100-7600"
    },
    "payloadws": {
      "payloadcdn": "GET / HTTP/1.1[crlf]Host: [host_port][crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]",
      "payloadwithpath": "GET /worryfree/ssh HTTP/1.1[crlf]Host: BUG[crlf]User-Agent: [ua][crlf]Upgrade: websocket[crlf][crlf]"
    }
  }
}
END
  cat "/etc/xray/${Login}-ssh-panel.json" | jq .
}

ResponseCheckAllService() {
  cat > "/etc/xray/panel-check-service.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Check All Services Success"
  },
  "data": {
    "ssh": "${SrvSSH}",
    "dropbear": "${SrvDROPBEAR}",
    "openvpn": "${SrvOPENVPN}",
    "squid": "${SrvSQUID}",
    "nginx": "${SrvNGINX}",
    "badvpn": "${SrvBADVPN}",
    "vmess": "${SrvVMESS}",
    "vless": "${SrvVLESS}",
    "trojan": "${SrvTROJAN}",
    "slowdns": "${SrvSLOWDNS}",
    "dnsovpn": "${SrvDNSOVPN}",
    "web": "${SrvWEB}",
    "http": "${SrvHTTP}",
    "https": "${SrvHTTPS}"
  }
}
END
  cat "/etc/xray/panel-check-service.json" | jq .
}

JsonRenew() {
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
  cat > "/etc/xray/${user}-renew-panel.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Success renew ${user}"
  },
  "data": {
    "username": "${user}",
    "quota": "${e}",
    "from": "${exp}",
    "to": "${exp4}"
  }
}
END
  cat "/etc/xray/${user}-renew-panel.json" | jq .
}

JsonDelete() {
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
  cat > "/etc/xray/${user}-delete-panel.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Success delete ${user}"
  },
  "data": {
    "username": "${user}"
  }
}
END
  cat "/etc/xray/${user}-delete-panel.json" | jq .
}

JsonDeleteMulti() {
  cat > "/etc/xray/panel-delete-multi.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Success use the function"
  },
  "data": [
    
  ]
}
END
}

JsonChangeLimit() {
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
  cat > "/etc/xray/${user}-cl-panel.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Success change limit ${user}"
  },
  "data": {
    "username": "${user}",
    "message": "${Limit} IP"
  }
}
END
  cat "/etc/xray/${user}-cl-panel.json" | jq .
}

JsonChangeLimitAll() {
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
  cat > "/etc/xray/${user}-cla-panel.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Success change limit"
  },
  "data": {
    "username": "All Account",
    "message": "${Limit} IP"
  }
}
END
  cat "/etc/xray/${user}-cla-panel.json" | jq .
}

JsonChangeQuota() {
if [[ ${Quota} == 0 ]]; then
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
  cat > "/etc/xray/${user}-cq-panel.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Success change quota ${user}"
  },
  "data": {
    "username": "${user}",
    "message": "Unlimited"
  }
}
END
  cat "/etc/xray/${user}-cq-panel.json" | jq .
else
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
  cat > "/etc/xray/${user}-cq-panel.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Success change quota ${user}"
  },
  "data": {
    "username": "${user}",
    "message": "${Quota} GB"
  }
}
END
  cat "/etc/xray/${user}-cq-panel.json" | jq .
fi
}

JsonChangeQuotaAll() {
if [[ ${Quota} == 0 ]]; then
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
  cat > "/etc/xray/${user}-cqa-panel.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Success change quota"
  },
  "data": {
    "username": "All Account",
    "message": "Unlimited"
  }
}
END
  cat "/etc/xray/${user}-cqa-panel.json" | jq .
else
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
  cat > "/etc/xray/${user}-cqa-panel.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Success change quota"
  },
  "data": {
    "username": "All Account",
    "message": "${Quota} GB"
  }
}
END
  cat "/etc/xray/${user}-cqa-panel.json" | jq .
fi
}

JsonChangeDomain() {
  cat > "/etc/xray/panel-domain.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Change Domain Success"
  },
  "data": {
    "from": "${From_Domain}",
    "to": "${DMN}"
  }
}
END
  cat "/etc/xray/panel-domain.json" | jq .
}

JsonUnlockAccount() {
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
  cat > "/etc/xray/${user}-jua-panel.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Unlock Account Success"
  },
  "data": {
    "username": "${user}",
    "pass_uuid": "${uuid}",
    "expired": "${exp}",
    "status_lock": "${is_status}"
  }
}
END
  cat "/etc/xray/${user}-jua-panel.json" | jq .
}

JsonLockAccount() {
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
  cat > "/etc/xray/${user}-jla-panel.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Lock Account Success"
  },
  "data": {
    "username": "${user}",
    "pass_uuid": "${uuid}",
    "expired": "${exp}",
    "status_lock": "${is_status}"
  }
}
END
  cat "/etc/xray/${user}-jla-panel.json" | jq .
}

JsonListUsersAllAccount() {
  cat > "/etc/xray/panel-list-users.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Total INITOTALUSERS"
  },
  "total": INITOTALUSERS,
  "data": [
    
  ]
}
END
}

JsonModifyAccount() {
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
  cat > "/etc/xray/${user}-jma-panel.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Modify Account Success"
  },
  "data": {
    "username": "${user}",
    "pass_uuid": "${uuid}"
  }
}
END
  cat "/etc/xray/${user}-jma-panel.json" | jq .
}

JsonDeleteAllRecovery() {
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
  cat > "/etc/xray/${user}-jdar-panel.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Delete All Account Recovery Success"
  },
  "data": {
    "username": "${user}"
  }
}
END
  cat "/etc/xray/${user}-jdar-panel.json" | jq .
}

JsonChangePasswordRoot() {
  cat > "/etc/xray/jcp-panel.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Success change password root"
  },
  "data": {
    "username": "root",
    "password": "${Pass}"
  }
}
END
  cat "/etc/xray/jcp-panel.json" | jq .
}

JsonMyFeatures() {
  cat > "/etc/xray/jmf-panel.json" <<-END
{
  "meta": {
    "code": 200,
    "status": "success",
    "ip_address": "${MYIP}",
    "message": "Success Use This Function"
  },
  "data": {}
}
END
  cat "/etc/xray/jmf-panel.json" | jq .
}

JsonMyFeaturesFalse() {
  cat > "/etc/xray/jmff-panel.json" <<-END
{
  "meta": {
    "code": 401,
    "status": "error",
    "ip_address": "${MYIP}",
    "message": "Success Use This Function"
  },
  "data": {}
}
END
  cat "/etc/xray/jmff-panel.json" | jq .
}

JsonNotExists() {
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
cat > "/etc/xray/${user}-ne-panel.json" <<-END
{
  "meta": {
    "code": 401,
    "status": "error",
    "ip_address": "${MYIP}",
    "message": "Client ${user} not exists, Try another name"
  },
  "data": {
    
  }
}
END
  cat "/etc/xray/${user}-ne-panel.json" | jq .
}

JsonExists() {
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
cat > "/etc/xray/${user}-e-panel.json" <<-END
{
  "meta": {
    "code": 401,
    "status": "error",
    "ip_address": "${MYIP}",
    "message": "Client ${user} exists, Try another name"
  },
  "data": {
    
  }
}
END
  cat "/etc/xray/${user}-e-panel.json" | jq .
}

JsonExistsUuid() {
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
cat > "/etc/xray/${user}-eu-panel.json" <<-END
{
  "meta": {
    "code": 401,
    "status": "error",
    "ip_address": "${MYIP}",
    "message": "Uuid ${uuid} exists, Try another uuid"
  },
  "data": {
    
  }
}
END
  cat "/etc/xray/${user}-eu-panel.json" | jq .
}

SpecialCharacters() {
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
cat > "/etc/xray/${user}-sc-panel.json" <<-END
{
  "meta": {
    "code": 401,
    "status": "error",
    "ip_address": "${MYIP}",
    "message": "Don't use special characters, Follow the instructions given"
  },
  "data": {
    
  }
}
END
  cat "/etc/xray/${user}-sc-panel.json" | jq .
}

DomainNotSame() {
  cat > "/etc/xray/panel-domainotsame.json" <<-END
{
  "meta": {
    "code": 401,
    "status": "error",
    "ip_address": "${MYIP}",
    "message": "Change Domain Failed, Please Pointing ${DMN} to IP ${MYIP}"
  },
  "data": {
    
  }
}
END
  cat "/etc/xray/panel-domainotsame.json" | jq .
}

Only_Number() {
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
cat > "/etc/xray/${user}-on-panel.json" <<-END
{
  "meta": {
    "code": 401,
    "status": "error",
    "ip_address": "${MYIP}",
    "message": "Don't use only numbers, Try another name"
  },
  "data": {
    
  }
}
END
  cat "/etc/xray/${user}-on-panel.json" | jq .
}

JustUseNumber() {
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
  cat > "/etc/xray/${user}-jun-panel.json" <<-END
{
  "meta": {
    "code": 401,
    "status": "error",
    "ip_address": "${MYIP}",
    "message": "Please use only numbers"
  },
  "data": {
    
  }
}
END
  cat "/etc/xray/${user}-jun-panel.json" | jq .
}

Characters_User() {
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
cat > "/etc/xray/${user}-lc-panel.json" <<-END
{
  "meta": {
    "code": 401,
    "status": "error",
    "ip_address": "${MYIP}",
    "message": "Minimum 4 and Maximum 16 characters, Try another name"
  },
  "data": {
    
  }
}
END
  cat "/etc/xray/${user}-lc-panel.json" | jq .
}

Characters_Uuid() {
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
cat > "/etc/xray/${user}-lcu-panel.json" <<-END
{
  "meta": {
    "code": 401,
    "status": "error",
    "ip_address": "${MYIP}",
    "message": "Maximum password/uuid 36 characters, Try another password/uuid"
  },
  "data": {
    
  }
}
END
  cat "/etc/xray/${user}-lcu-panel.json" | jq .
}

Access_Denied() {
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
cat > "/etc/xray/${user}-ad-panel.json" <<-END
{
  "meta": {
    "code": 401,
    "status": "error",
    "ip_address": "${MYIP}",
    "message": "Script access denied, Your IP not registered"
  },
  "data": {
    
  }
}
END
  cat "/etc/xray/${user}-ad-panel.json" | jq .
}

Script_Expired() {
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
cat > "/etc/xray/${user}-se-panel.json" <<-END
{
  "meta": {
    "code": 401,
    "status": "error",
    "ip_address": "${MYIP}",
    "message": "Script expired, Renew first before accessing this API"
  },
  "data": {
    
  }
}
END
  cat "/etc/xray/${user}-se-panel.json" | jq .
}

Only_Potato() {
  if [[ ${user} =~ ^[a-z0-9_\-]+$ ]]; then
    local user="${user}"
  else
    local user="SpecialCharacters"
  fi
cat > "/etc/xray/${user}-op-panel.json" <<-END
{
  "meta": {
    "code": 401,
    "status": "error",
    "ip_address": "${MYIP}",
    "message": "Only Support For Potato Script"
  },
  "data": {
    
  }
}
END
  cat "/etc/xray/${user}-op-panel.json" | jq .
}









