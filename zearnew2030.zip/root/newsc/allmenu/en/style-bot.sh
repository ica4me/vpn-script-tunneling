#!/bin/bash

SendtoBotAllVmess() {
echo "<code>————————————————————————————————————</code>"
echo "<code>               VMESS</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>Remarks        : ${user}"
echo "CITY           : ${city}"
echo "ISP            : ${isp}"
echo "Domain         : ${domain}"
echo "Port TLS       : 443,8443"
echo "Port none TLS  : 80,8080"
echo "Port any       : 2052,2053,8880"
echo "id             : ${uuid}"
echo "alterId        : 0"
echo "Security       : auto"
echo "network        : ws,grpc,upgrade"
echo "path ws        : /vmess - /whatever"
echo "serviceName    : vmess"
echo "path upgrade   : /upvmess"
echo "Expired On     : ${exp}</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>           VMESS WS TLS</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>${vmesslink1}</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>          VMESS WS NO TLS</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>${vmesslink2}</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>             VMESS GRPC</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>${vmesslink3}</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>         VMESS Upgrade TLS</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>${vmesslink4}</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>        VMESS Upgrade NO TLS</code>"
echo "<code>————————————————————————————————————</code>"
echo "<code>${vmesslink5}</code>"
echo "<code>————————————————————————————————————</code>"
}

SendtoBotAllVless() {
  TEXT="<code>————————————————————————————————————</code>
<code>               VLESS</code>
<code>————————————————————————————————————</code>
<code>Remarks        : ${user}
CITY           : ${city}
ISP            : ${isp}
Domain         : ${domain}
Port TLS       : 443,8443
Port none TLS  : 80,8080
Port any       : 2052,2053,8880
id             : ${uuid}
Encryption     : none
Network        : ws,grpc,upgrade
Path ws        : /vless
serviceName    : vless
Path upgrade   : /upvless
Expired On     : ${exp}</code>
<code>————————————————————————————————————</code>
<code>            VLESS WS TLS</code>
<code>————————————————————————————————————</code>
<code>${clip1}</code>
<code>————————————————————————————————————</code>
<code>          VLESS WS NO TLS</code>
<code>————————————————————————————————————</code>
<code>${clip2}</code>
<code>————————————————————————————————————</code>
<code>             VLESS GRPC</code>
<code>————————————————————————————————————</code>
<code>${clip3}</code>
<code>————————————————————————————————————</code>
<code>          VLESS Upgrade TLS</code>
<code>————————————————————————————————————</code>
<code>${clip4}</code>
<code>————————————————————————————————————</code>
<code>        VLESS Upgrade NO TLS</code>
<code>————————————————————————————————————</code>
<code>${clip5}</code>
<code>————————————————————————————————————</code>
"
  echo "${TEXT}"
}

SendtoBotAllTrojan() {
  TEXT="<code>————————————————————————————————————</code>
<code>               TROJAN</code>
<code>————————————————————————————————————</code>
<code>Remarks      : ${user}
CITY         : ${city}
ISP          : ${isp}
Domain       : ${domain}
Port         : 443,8443
Port any     : 2052,2053,8880
Key          : ${uuid}
Network      : ws,grpc,upgrade
Path ws      : /trojan
serviceName  : trojan
Path upgrade : /uptrojan</code>
<code>————————————————————————————————————</code>
<code>           TROJAN WS TLS</code>
<code>————————————————————————————————————</code>
<code>${clip1}</code>
<code>————————————————————————————————————</code>
<code>            TROJAN GRPC</code>
<code>————————————————————————————————————</code>
<code>${clip2}</code>
<code>————————————————————————————————————</code>
<code>         TROJAN Upgrade TLS</code>
<code>————————————————————————————————————</code>
<code>${clip3}</code>
<code>————————————————————————————————————</code>
<code>Expired On  : ${exp}</code>
<code>————————————————————————————————————</code>
"
  echo "${TEXT}"
}

SendtoBotAllSsh() {
  if [[ ${ns} != 'no' && ${pub} != 'no' ]]; then
    TEXT="<code>
   Account Created Successfully
————————————————————————————————————
HOST            : </code><code>${domain}</code>
<code>NameServer      : </code><code>${ns}</code>
<code>Username        : </code><code>${Login}</code>
<code>Password        : </code><code>${Pass}</code>
<code>PUB Key         : </code><code>${pub}</code>
<code>————————————————————————————————————
Expired         : ${exp}
————————————————————————————————————
TLS             : 443,8443
None TLS        : 80,8080
Any             : 2082,2083,8880
OpenSSH         : 444
Dropbear        : 90
————————————————————————————————————
SlowDNS         : 53,5300
UDP-Custom      : 1-65535
OHP %2B SSH       : 9080
Squid Proxy     : 3128
UDPGW           : 7100-7600
OpenVPN TCP     : 80,1194
OpenVPN SSL     : 443
OpenVPN UDP     : 25000
OpenVPN DNS     : 53
OHP %2B OVPN      : 9088
————————————————————————————————————
http://${domain}:81/myvpn-config.zip
————————————————————————————————————</code>
"
    echo "${TEXT}"
  else
    TEXT="<code>
   Account Created Successfully
————————————————————————————————————
HOST            : </code><code>${domain}</code>
<code>Username        : </code><code>${Login}</code>
<code>Password        : </code><code>${Pass}</code>
<code>————————————————————————————————————
Expired         : ${exp}
————————————————————————————————————
TLS             : 443,8443
None TLS        : 80,8080
Any             : 2082,2083,8880
OpenSSH         : 444
Dropbear        : 90
————————————————————————————————————
SlowDNS         : 53,5300
UDP-Custom      : 1-65535
OHP %2B SSH       : 9080
Squid Proxy     : 3128
UDPGW           : 7100-7600
OpenVPN TCP     : 80,1194
OpenVPN SSL     : 443
OpenVPN UDP     : 25000
OpenVPN DNS     : 53
OHP %2B OVPN      : 9088
————————————————————————————————————
http://${domain}:81/myvpn-config.zip
————————————————————————————————————</code>
"
    echo "${TEXT}"
  fi
}
